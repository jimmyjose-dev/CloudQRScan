//
//  UIKeyboardAccessoryView.h
//  VMCategories
//
//  Created by Jimmy on 16/06/13.
//  Copyright (c) 2013 VarshylMobile. All rights reserved.
//

#import "UIAccessoryView.h"


/*

 UIAccessoryView *v = [[UIAccessoryView alloc] init];
 v.delegate = self;
 v.dataSource = self;
 [field1 setInputAccessoryView:v];
 [field2 setInputAccessoryView:v];
 [field3 setInputAccessoryView:v];
 
 dataSource = [[NSMutableArray alloc] init];
 [dataSource addObject:field1];
 [dataSource addObject:field2];
 [dataSource addObject:field3];
 [v reloadData];
 
 }
 

 
 #pragma mark - UIAccessoryView
 - (void) didPressedDoneButton {
 [_field resignFirstResponder];
 }
 
 - (NSInteger) numberOfFields {
 return [dataSource count];
 }
 
 - (UITextField *)fieldForRowAtIndex:(int)index {
 UITextField *f = [dataSource objectAtIndex:index];
 
 return f;
 }
 
 #pragma mark - UITextField
 - (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
 if ([string isEqualToString:@"\n"]) {
 [textField resignFirstResponder];
 }
 
 return YES;
 }
 
 - (void)textFieldDidBeginEditing:(UITextField *)textField {
 _field = textField;
 }


*/
//
//  UIViewController+Utils.h
//  VMCategories
//
//  Created by Jimmy on 10/04/13.
//  Copyright (c) 2013 VarshylMobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Utils)
- (id)initByAppendingDeviceName:(NSString *)forNibName;
- (id)initByAppendingDeviceName:(NSString *)forNibName withTitle:(NSString*)title;
@end

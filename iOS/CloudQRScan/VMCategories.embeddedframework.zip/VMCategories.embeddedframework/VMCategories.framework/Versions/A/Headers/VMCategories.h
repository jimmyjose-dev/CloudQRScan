//
//  VMCategories.h
//  VMCategories
//
//  Created by Jimmy on 14/03/13.
//  Copyright (c) 2013 VarshylMobile. All rights reserved.
//

//Note: - In build settings -> other linker flags add "-ObjC"
//Add QuartCore.framework

#import "AllCategories.h"
#import "AllOthers.h"
